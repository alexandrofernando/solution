package triplet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Solution_ {

	public Solution_() {
		// TODO Auto-generated constructor stub
	}
	
	public  int newRowSet(int N, String S, List<String> L ) {
		int totalAvail = N;
	    Set<String> set = new HashSet<String>(L);
	    for (int i = 1; i <= N; i++) {
	    for (String s :S.split("")) {
	    	if(!set.add(i+s)) { 
			totalAvail --;
            break;};
	    }}
	    return totalAvail;
	}
	
	
	 static int power1(int x, int y)
	    {
	        if (y == 0)
	            return 1;
	        else if (y % 2 == 0)
	            return power1(x, y / 2) * power1(x, y / 2);
	        else
	            return x * power1(x, y / 2) * power1(x, y / 2);
	    }
	    static int power2(int x, int y)
	    {
	        int temp;
	        if( y == 0)
	            return 1;
	        temp = power2(x, y/2); 
	         
	        if (y%2 == 0)
	            return temp*temp;
	        else
	        {
	            if(y > 0)
	                return x * temp * temp;
	            else
	                return (temp * temp) / x;
	        }
	    } 
	     
	    static /* Function to calculate x raised to the power y in O(logn)*/
	    int power3(int x, int  y)
	    {
	        int temp;
	        if( y == 0)
	            return 1;
	        temp = power3(x, y/2);
	        if (y%2 == 0)
	            return temp*temp;
	        else
	            return x*temp*temp;
	    }

    public int solution(int N, String S) {
        // write your code in Java SE 8
	

    List<String> reservedList = Arrays.asList(S.split(" "));
    
    

    return newRowSet(N,"ABC", reservedList)+ newRowSet(N,"EF", reservedList)+ newRowSet(N,"HJK", reservedList);
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(new Solution_().solution(2, "1A 2F 1C"));
        int x = 2;
        int y = 3;
        System.out.println(power1(x, y));
       System.out.println(power2(x, y));
       System.out.println(power3(x, y));
	}

}
