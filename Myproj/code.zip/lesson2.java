import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.Function;
import java.util.Set;
import java.util.stream.Collectors;

public abstract class lesson2 {
 int grade; 
 int count;
 String name; 
 
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    	String[][] myLesson = new String[][] {
    	    {  "paul", "10"},
    	    { "peter", "15"},
    	    { "justin", "3"},
    	    { "charles", "9"},
    	    { "roman", "18"},
    	    {"peter", "15"},
    	    { "anna", "11"},
    	    { "paul", "5"},
    	    { "july", "17"},
    	    { "anna", "7"},
    	};
    	String[] Element;
    	List<String[]> list = Arrays.asList(myLesson);
    //	Map<String, List<Obj ect[]>> resultMap = 
    		//	list.stream().collect(Collectors.groupingBy(o -> (String)o[0]), Collectors.averagingInt( o -> Integer.parseInt(o[1]))   );//List<lesson> list = Arrays.asList(myLesson);
    	
    	
    	double i = (double) ( new TreeSet<Double>( Arrays.asList(myLesson).stream().collect(Collectors.groupingBy(w -> w[0] , Collectors.averagingInt(w -> Integer.parseInt(w[1])))).values())).last();
    	System.out.println(i );	
    	
			Set<Object> sortedSet =   
	    				 list.stream()
	    					.collect(Collectors.groupingBy(w -> w[0] ,( Collectors.averagingInt(w -> Integer.parseInt(w[1])))))
.values().stream().collect(Collectors.toSet());
				  Character[] chars = new Character[]
                     { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
				  
					Map<Character, Character> m = 
	                        Arrays.stream(chars).collect(
	                  Collectors.toMap((Character k) -> 
	                                       Character.toUpperCase(k),
	                                   Function.identity()));	      	    					
					System.out.println(m);
	    					
int k =  	 (int)(double)list.stream()
	    	.collect(Collectors.groupingBy(w -> w[0] , Collectors.averagingInt(w -> Integer.parseInt(w[1]))))
            .values().stream() 
//	.collect(Collectors.toSet());
            .collect( Collectors.toCollection(TreeSet::new))
            .last();
//     .stream()            .flatMap(List::stream)            .map‌​(Employee::getFirstN‌​ame)            .collect(toSet()‌​);	
	    					//.collect(Collectors.toSet( HashSet::new, HashSet::addAll, HashSet::addAll ));
int j = (int) k;    					System.out.println(k);



	    					
					Map<Object, Double> sortedMap1_ = 	
							list.stream()
     	    					.collect(Collectors.groupingBy(w -> w[0] , Collectors.averagingInt(w -> Integer.parseInt(w[1]))));
     	    			
     	    					
     	    					 List<Integer> result = new ArrayList(sortedMap1_.values());
     	    					 Set<Integer> result1 = new HashSet(sortedMap1_.values());
     	    					Set<Integer> result3 = new TreeSet(sortedMap1_.values());
     	    					System.out.println(((TreeSet) result3).last());
//	new TreeSet(sortedSet1);  .values().stream().flatMap(Set::stream).collect(Collectors.toSet());	

				//	String[] result = contactNumber.values().toArray(new String[0]);
				//   List<String> targetList = new ArrayList<>(sourceMap.values());
				// Set<String> targetSet = new HashSet<>(sourceMap.values());
					//TreeMap<String, String> myMap = new TreeMap<String, String>();
					//String first = myMap.firstEntry().getValue();
					//String firstOther = myMap.get(myMap.firstKey());
					//map.values().toArray()[0]
					//Map<String, String> map = ...;  // wherever you get this from

				//Map.Entry<String, String> entry = map.entrySet().iterator().next();
		
				//System.out.println("Key: "+entry.getKey()+", Value: "+entry.getValue());
    	
    	Map<Object, Object> sortedMap__ =   
    					list.stream()
    					.collect(Collectors.groupingBy(w -> w[0] , Collectors.counting()))
    					.entrySet().stream()
    					.sorted((e1, e2) -> (int)(e2.getValue() - e1.getValue()))
    					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> a, LinkedHashMap::new));
    					System.out.println(sortedMap__);
    	    			
    					
    		  Map<Object, Object> sortedMap_ =   
    	    					list.stream()
    	    					.collect(Collectors.groupingBy(w -> w[0] , Collectors.averagingInt(w -> Integer.parseInt(w[1]))))
    	    					.entrySet().stream()
    	    					.sorted((e1, e2) -> (int)(e2.getValue() - e1.getValue()))
    	    					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> a, LinkedHashMap::new));
    	    					System.out.println(sortedMap_);
    	    					
    	    Map<Object, Object> sortedMap =   
    	      	    					list.stream()
    	      	    					.collect(Collectors.groupingBy(w -> w[0] , Collectors.averagingInt(w -> Integer.parseInt(w[1]))))
    	      	    					.entrySet().stream()
    	      	    					.sorted((e1, e2) -> (int)(e2.getValue() - e1.getValue()))
    	      	    					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> a, LinkedHashMap::new));
    	      	    					System.out.println(sortedMap.values().stream().findFirst().get());
    	
    	      	    					
    			Map<Object, Object> sortedMap1 =   
    	    	      	    					list.stream()
    	    	      	    					.collect(Collectors.groupingBy(w -> w[0] , Collectors.averagingInt(w -> Integer.parseInt(w[1]))))
    	    	      	    					.entrySet().stream()
    	    	      	    					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> a, TreeMap::new));
    	    	      	    					System.out.println(sortedMap1.keySet().stream().findFirst().get());
    	  
    	    	      	    					
    	    	      	    					

	}
	
	public lesson2(String[] lesson) {
		
		this.grade = Integer.parseInt(lesson[0]);
		//this.count = count;
		this.name = lesson[1];
	}

	public lesson2(int grade, int count, String name) {
		super();
		this.grade = grade;
		this.count = count;
		this.name = name;
	}

}
