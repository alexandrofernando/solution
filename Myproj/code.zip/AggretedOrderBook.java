import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

class AggretedOrder extends Book {


	
	private char msgType;
	private int OrderId;

	private char side;

	public char getSide() {
		return side;
	}

	public void setSide(char side) {
		this.side = side;
	}

	AggretedOrder(String symbol, double price, char msgType, int orderId, int stockSize, char side) {
		super(symbol, price, stockSize);
		
		
		this.msgType = msgType;
		OrderId = orderId;
		
		this.side = side;
	}

	static NumberFormat formatter = new DecimalFormat("#0.00");

	@Override
	public String toString() {
		return String.format("OrderId: %d\r\nMsgType: %s\r\nSymbol: %s\r\nPrice: %s\r\nSize: %d\r\n", OrderId, msgType,
				getSymbol(), formatter.format(getPrice()), getStockSize());
	}


	public char getMsgType() {
		return msgType;
	}

	public void setMsgType(char msgType) {
		this.msgType = msgType;
	}

	public int getOrderId() {
		return OrderId;
	}

	public void setOrderId(int orderId) {
		OrderId = orderId;
	}



}

class Book {

	public Book(String symbol, double price, int stockSize) {
		super();
		this.symbol = symbol;
		this.price = price;
		this.stockSize = stockSize;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getStockSize() {
		return stockSize;
	}

	public void setStockSize(int stockSize) {
		this.stockSize = stockSize;
	}

	private String symbol;
	private double price;
	private int stockSize;
	static NumberFormat formatter = new DecimalFormat("#0.00");

	@Override
	public String toString() {
		return String.format("Symbol: %s\r\nPrice: %s\r\nSize: %d\r\n", symbol, formatter.format(price), stockSize);
	}

}



public class AggretedOrderBook {

	
	static Set<Integer> deleteSet = new HashSet<Integer>();

	
	
	
	static List<Book> getBuyAndSellBookBySymbole(List<Book> myBook, String symbole) {

		return BuyAndSellBookBySymbole(myBook).get(symbole);
	}

	
	
	
	static Map<String, List<Book>> BuyAndSellBookBySymbole(List<Book> myBook) {

		return myBook.stream().collect(Collectors.groupingBy(Book::getSymbol, Collectors.toList()));
	}
	
	
	

	static List<Book> flattenedBuyAndSellBook(List<AggretedOrder> aggrOrder) {

		return aggrOrder.stream()
				.collect(Collectors.groupingBy(AggretedOrder::getSymbol,
						Collectors.groupingBy(AggretedOrder::getPrice,
								Collectors.summingInt(AggretedOrder::getStockSize))))
				.entrySet().stream().flatMap(e1 -> e1.getValue().entrySet().stream()
						.map(e2 -> new Book(e1.getKey(), e2.getKey(), e2.getValue())))
				.collect(Collectors.toList());
	}

	
	
	static List<Book> flattenedBuyAndSellBookUpdated(List<AggretedOrder> aggrOrder) {

		return aggrOrder.stream().filter(n -> !deleteSet.contains(n.getOrderId()))
				.collect(Collectors.groupingBy(AggretedOrder::getSymbol,
						Collectors.groupingBy(AggretedOrder::getPrice,
								Collectors.summingInt(AggretedOrder::getStockSize))))
				.entrySet().stream().flatMap(e1 -> e1.getValue().entrySet().stream()
						.map(e2 -> new Book(e1.getKey(), e2.getKey(), e2.getValue())))
				.collect(Collectors.toList());
	}

	
	
	static List<Book> flattenedBuyBook(List<AggretedOrder> aggrOrder) {

		return aggrOrder.stream().filter(n -> n.getSide() == 'B' && !deleteSet.contains(n.getOrderId()))
				.collect(Collectors.groupingBy(AggretedOrder::getSymbol,
						Collectors.groupingBy(AggretedOrder::getPrice,
								Collectors.summingInt(AggretedOrder::getStockSize))))
				.entrySet().stream().flatMap(e1 -> e1.getValue().entrySet().stream()
						.map(e2 -> new Book(e1.getKey(), e2.getKey(), e2.getValue())))
				.collect(Collectors.toList());
	}
	
	

	static List<Book> flattenedSellBook(List<AggretedOrder> aggrOrder) {

		return aggrOrder.stream().filter(n -> n.getSide() == 'S' && !deleteSet.contains(n.getOrderId()))
				.collect(Collectors.groupingBy(AggretedOrder::getSymbol,
						Collectors.groupingBy(AggretedOrder::getPrice,
								Collectors.summingInt(AggretedOrder::getStockSize))))
				.entrySet().stream().flatMap(e1 -> e1.getValue().entrySet().stream()
						.map(e2 -> new Book(e1.getKey(), e2.getKey(), e2.getValue())))
				.collect(Collectors.toList());
	}

	public static void main(String[] args) throws FileNotFoundException {
		Scanner input = new Scanner(new File("input.txt"));
		input.useDelimiter(",|\n");

		List<AggretedOrder> aggrOrder = new ArrayList<AggretedOrder>();
		List<AggretedOrder> aggrOrderBuyBook = new ArrayList<AggretedOrder>();
		List<AggretedOrder> aggrOrderSellBook = new ArrayList<AggretedOrder>();

		while (input.hasNext()) {

			char msgType = input.next().trim().charAt(0);
			String symbol = input.next();
			if (msgType == 'D') {

				int orderId = input.nextInt();

				deleteSet.add(orderId);
			}

			else {

				char side = input.next().trim().charAt(0);
				int orderId = input.nextInt();
				double price = Double.valueOf(input.next().substring(1));
				int stockSize = input.nextInt();

				aggrOrder.add(
						new AggretedOrder(symbol, price, msgType, orderId, side == 'B' ? stockSize : -stockSize, side));
				if (side == 'B')
					aggrOrderBuyBook.add(new AggretedOrder(symbol, price, msgType, orderId, stockSize, side));
				else
					aggrOrderSellBook.add(new AggretedOrder(symbol, price, msgType, orderId, stockSize, side));

			}

		}

		if (args.length > 1) { // If any arguments provided

			if (args[0] == "s")
				System.out.println(getBuyAndSellBookBySymbole(flattenedBuyAndSellBook(aggrOrder), args[1]));
		} else if (args.length > 0) {
			if (args[0] == "a")
				System.out.println(BuyAndSellBookBySymbole(flattenedBuyAndSellBook(aggrOrder)));
			if (args[0] == "c")
				System.out.println(BuyAndSellBookBySymbole(flattenedBuyAndSellBookUpdated(aggrOrder)));
		} else {
			System.out.println("No arguments provided.");
			System.out.println("Sell Book");
			System.out.println(flattenedBuyBook(aggrOrder));
			System.out.println("Buy Book.");
			System.out.println(flattenedSellBook(aggrOrder));
		}

	}
}