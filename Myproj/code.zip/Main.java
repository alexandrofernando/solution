import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class Main {
  /**
   * Iterate through each line of input.
   */
   
   private static String reverse(String[] initial, int k) {
    StringBuilder output = new StringBuilder();
    for (int i = k - 1; i < initial.length; i += k) {
        for (int j = i; i - j <= k - 1; j--) {
            output.append(',').append(initial[j]);
        }
    }

    for (int i = initial.length - initial.length % k; i < initial.length; i++) {
        output.append(',').append(initial[i]);
    }
    return output.substring(1);
}
   
   static int SubCount(String initial, String seq)
   {
           int m = initial.length(), n = seq.length();
       int[][] count = new int[m+1][n+1];
       for(int i=0;i<=m;i++) count[i][0] = 1;
       for(int i=1;i<=m;i++) {
           for(int j=1;j<=n;j++) {
               count[i][j] = count[i-1][j];
               if(initial.charAt(i-1)==seq.charAt(j-1)) count[i][j]+=count[i-1][j-1];
           }
       }
       return count[m][n];
   }
  public static void main(String[] args) throws IOException {
    InputStreamReader reader = new InputStreamReader(System.in, StandardCharsets.UTF_8);
    BufferedReader in = new BufferedReader(reader);
    String line;
    while ((line = in.readLine()) != null) {
      String[] ss=line.split(";");


      System.out.println(reverse(ss[0].split(","),  Integer.parseInt(ss[1])));
    }
  }
}
