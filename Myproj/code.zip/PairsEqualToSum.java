import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class PairsEqualToSum {

public static void main(String[] args) {
    int a[] = {1,10,5,8,2,12,6,4};
    findPairs1(a,10);
    findPairs2(a,10);
    findPairs3(a,10);
    System.out.println(  ": " );

}


//Method1 - O(N) use a Map to insert values as keys & check for number's complement in map
    static void findPairs1(int[]a, int sum){
        Map<Integer, Integer> pairs = new HashMap<Integer, Integer>();
        for(int i=0; i<a.length; i++){
            if(pairs.containsKey(sum-a[i]))
                System.out.println("("+a[i]+","+(sum-a[i])+")");
            else
               pairs.put(a[i], 0);
        }
    }


  //Method1 - O(N) use a Map to insert values as keys & check for number's complement in map
    static void findPairsDifference(int[]a, int diff){
        Map<Integer, Integer> pairs = new HashMap<Integer, Integer>();
        for(int i=0; i<a.length; i++){
            if(pairs.containsKey(diff-a[i]))
                System.out.println("("+a[i]+","+(diff-a[i])+")");
            else
               pairs.put(a[i], 0);
        }
    }

    
    public static void main1(String[] args){
		// TODO Auto-generated method stub
	
		  System.out.println(  ": " );
	}
//Method2 - O(nlog(n)) using Sort
static void findPairs2(int[]a, int sum){
        Arrays.sort(a);
        for(int i=0; i<a.length/2; i++){
            int complement = sum - a[i];
            int foundAtIndex = Arrays.binarySearch(a,complement);
            if(foundAtIndex >0 && foundAtIndex != i) //to avoid situation where binarySearch would find the original and not the complement like "5"
                System.out.println("("+a[i]+","+(sum-a[i])+")");
        }
 }
static boolean hasArrayTwoCandidates(int A[], 
        int arr_size, int sum)
{
int l, r;

/* Sort the elements */
Arrays.sort(A);

/* Now look for the two candidates 
in the sorted array*/
l = 0;
r = arr_size-1; 
while (l < r)
{
if(A[l] + A[r] == sum)
return true; 
else if(A[l] + A[r] < sum)
l++;
else // A[i] + A[j] > sum
r--;
} 
return false;
}
//Method 3 - Brute Force O(n^2)
static void findPairs3(int[]a, int sum){

    for(int i=0; i<a.length; i++){
        for(int j=i; j<a.length;j++){
            if(a[i]+a[j] == sum)
                System.out.println("("+a[i]+","+a[j]+")");
        }
    }
}

} 