
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;



public abstract class lesson {
 int grade; 
 int count;
 String name; 
 
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    	String[][] myLesson = new String[][] {
    	    {  "paul", "10"},
    	    { "peter", "15"},
    	    { "justin", "3"},
    	    { "charles", "9"},
    	    { "roman", "18"},
    	    {"peter", "15"},
    	    { "anna", "11"},
    	    { "paul", "5"},
    	    { "july", "17"},
    	    { "anna", "7"},
    	};
    	String[] Element;
    	List<String[]> list = Arrays.asList(myLesson);
    //	Map<String, List<Obj ect[]>> resultMap = 
    		//	list.stream().collect(Collectors.groupingBy(o -> (String)o[0]), Collectors.averagingInt( o -> Integer.parseInt(o[1]))   );//List<lesson> list = Arrays.asList(myLesson);
    	
    	
    	double i = (double) ( new TreeSet<Double>( Arrays.asList(myLesson).stream().collect(Collectors.groupingBy(w -> w[0] , java.util.stream.Collectors.averagingInt(w -> Integer.parseInt(w[1])))).values())).last();
    	System.out.println(i );	
    	
		
	    					
int k =  	 (int)(double)list.stream()
	    	.collect(Collectors.groupingBy(w -> w[0] , Collectors.averagingInt(w -> Integer.parseInt(w[1]))))
            .values().stream() 
//	.collect(Collectors.toSet());
            .collect( Collectors.toCollection(TreeSet::new))
            .last();
//     .stream()            .flatMap(List::stream)            .map‌​(Employee::getFirstN‌​ame)            .collect(toSet()‌​);	
	    					//.collect(Collectors.toSet( HashSet::new, HashSet::addAll, HashSet::addAll ));
int j = (int) k;    					System.out.println(k);


Map<String,List<Integer>> groupedStudents = new HashMap<String, List<Integer>>();
for (String[] student: list) {
    String key = student[0];
    if (groupedStudents.get(key) == null) {
        groupedStudents.put(key, new ArrayList<Integer>());
    }
    groupedStudents.get(key).add(Integer.parseInt(student[1]));
}
Map<String,Integer> groupedStuds = new HashMap<String, Integer>();
for (String[] student: list) {
   
    if (groupedStuds.get(student[0]) == null) {
    	groupedStuds.put(student[0], Integer.parseInt(student[1]));
    }
    groupedStuds.put(student[0], Integer.parseInt(student[1])+groupedStuds.get(student[0]));
}

TreeSet <Integer> treeadd = new TreeSet<Integer>();
for (String stud : groupedStudents.keySet()) {
	treeadd.add((int)calAverage(groupedStudents.get(stud)));
}

//Set <Integer> result3 =
/*HashSet<Integer> v = ((HashSet<Integer>) groupedStudents.values().stream().map(e->(int)calAverage(e))
.collect(Collectors.toSet()));*/	    					

int p =  groupedStudents.values().stream().map(e->(int)calAverage(e)).collect( Collectors.toCollection(TreeSet::new)).last();
 	    	      	    					
System.out.println(p);
	}

static  double calculateAverage(List <Integer> marks) {
    if (marks == null || marks.isEmpty()) {
        return 0;
    }

    double sum = 0;
    for (Integer mark : marks) {
        sum += mark;
    }

    return sum / marks.size();
}
static  double calAverage(List <Integer> marks) {
 
    return marks.stream().mapToDouble(d -> d).average().orElse(0.0);
}


}
