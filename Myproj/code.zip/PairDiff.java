package test;

// Java program to find a pair with the given difference
import java.io.*;
import java.util.Arrays;

class PairDiff
{
	 static int[] sortArr(int[] arr) {
		// TODO Auto-generated method stub
		return null;
	}
	
	 static boolean findPairs(int arr[],int k)
		{
			int N = arr.length;

			// Initialize positions of two elements
	
				int count = 0;
				for (int i = 0; i < N - 1; i++)
				{
					int j = i + 1;
					while((j < N) && (arr[j++] - arr[i]) < k);
					j--;
					while((j < N) && (arr[j++] - arr[i]) == k)
						{System.out.print("Pair Found: "+
								"( "+arr[i]+", "+ arr[j--]+" ) ");	break;}		
				}
			System.out.print("No such pair");
			return false;
		}
	 
	// The function assumes that the array is sorted
	static boolean findPair(int arr[],int n)
	{
		int size = arr.length;

		// Initialize positions of two elements
		int i = 0, j = 1;

		// Search for a pair
		while (i < size && j < size)
		{
			if (i != j && arr[j]-arr[i] == n)
			{
				System.out.print("Pair Found: "+
								"( "+arr[i]+", "+ arr[j]+" )");
				return true;
			}
			else if (arr[j] - arr[i] < n)
				j++;
			else
				i++;
		}

		System.out.print("No such pair");
		return false;
	}

	// Driver program to test above function
	public static void main (String[] args)
	{
		int arr[] = {1, 8, 30, 40, 90, 100};
		//int SortedArr[] = sortArr(arr);
		//Arrays.sort(arr); 
				
		int n = 60;
		findPairs(arr,n);
	}


}
/*This code is contributed by Devesh Agrawal*/
