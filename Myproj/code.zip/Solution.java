package triplet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Solution {


    public void mergesort(int[] A, int[] B, int[] a1, int[] a2, int start, int end) {
        if(start < end) {
            int mid = (start + end)/2;
         //   System.out.println(mid + ":" + start + ":" + end);
            mergesort(A, B, a1, a2, start, mid);
            mergesort(A, B, a1, a2, mid+1, end);
            merge(A, B, a1, a2, start, mid+1, end);
        }
    }

    public void merge(int[] A, int B[], int[] A1, int[] A2, int start, int mid, int end) {
        int leftEnd = mid - 1;
        int left = start;
        int size = end - start + 1;
        int k = start;

        while(left <= leftEnd && mid <= end) {
            if(A[left] <= A[mid]) {
                A1[k] = A[left];
                A2[k] = B[left];
                k++; left++;
            }
            else {
                A1[k] = A[mid];
                A2[k] = B[mid];
                k++; mid++;
            }
        }
        while(left <= leftEnd) {
            A1[k] = A[left];
            A2[k] = B[left];
            left++; k++;
        }
        while(mid <= end) {
            A1[k] = A[mid];
            A2[k] = B[mid];
            mid++; k++;
        }
        for(int i = 0; i < size; i++) {
            A[end] = A1[end];
            B[end] = A2[end];
            end--;
        }
    }



    public int solution(int[] A, int[] B) {
       
    	int pairWise = 0;
        
        int[] arr1 = new int[A.length];
        int[] arr2 = new int[A.length];
        
        mergesort(A, B, arr1, arr2, 0, A.length-1);
      
          for(int i = 0; i < A.length; i++) {
           
        	  if(i != 0 && A[i] <= B[i-1]) {
                B[pairWise-1] = B[i-1] > B[i] ? B[i-1] : B[i];
                A[pairWise-1] = A[i-1];
            }
            else {
                pairWise++; 
            }
        }
        return pairWise;
   
    }


    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Solution s = new Solution();
        /*
         * [1, 12, 42, 70, 36, -4, 43, 15], [5, 15, 44, 72, 36, 2, 69, 24]
         */
        int[] a = {1,12,42,70,36,-4,43,15};
        int[] b = {5,15,44,72,36,2,69,24};
        int cnt = s.solution(a, b);
        System.out.println(cnt);
    }

}