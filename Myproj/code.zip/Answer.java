package triplet;

import java.util.HashMap;
import java.util.List;

import org.w3c.dom.ranges.Range;

public class Answer {

	/**
	 * Returns an integer denoting the number of perfect numbers less than or equal
	 * to input.
	 *
	 * This method declaration must be kept unmodified.
	 *
	 * @param input
	 *            an integer
	 * @return an integer
	 */
	public static int answer(int input) {
		int count = 0;
		for (int i = 1; i <= input; i++) {

			if (isPerfect(i))
				++count;
		}
		return count;
	}

	/**
	 * Returns a boolean value denoting whether the input is a perfect number or
	 * not.
	 *
	 * @param input
	 *            an integer
	 * @return true if input is a perfect number, false otherwise
	 */
	public static boolean isPerfect(int input) {
		int[] divsrs = new int[500];
		// System.out.println("why2_"+ " " + input);
		getDivisors(input, divsrs);

		boolean isPerfect = false;
		int sum = 0;
		for (int i = 0; i < 500; i++) {

			sum += divsrs[i];
		}
		if (sum == input)

			isPerfect = true;

		return isPerfect;
	}

	/**
	 * Fills an input array with divisors
	 *
	 * @param input
	 *            a number whose divisors are to be generated
	 * @param divsr
	 *            an array to be filled with divisors
	 */
	public static void getDivisors(int input, int[] divsr) {

		int index = 0;
		for (int j = 1; j < input; j++) {

			if (input % j == 0) {

				divsr[index] = j;
				index++;
			}
		}
	}

	static String x(int a, int b, int c, String s) {
		int t = 0;
		for (; b <= c;)
			if ((b++ + "").contains(a + "")) {
				t++;
				s += t == 1 ? String.valueOf(b - 1) : "-" + String.valueOf(b - 1);
			}
		return s;
	}

	static String find_numbers(int digit, int start, int end) {
		// System.out.println("see"+x( digit, start, end));
		String s = "";

		int time = 0;
		for (; start <= end;)
			if ((start++ + "").contains(digit + "")) {
				time++;
				s += time == 1 ? String.valueOf(start - 1) : "-" + String.valueOf(start - 1);
			}
		return s;

	}
    interface StringSupplier {
        String getNext();
    }

    public int[] solution(int[] A) {
        int i;
        int r[] = new int[A.length];
        for(i=0;i<A.length;i++){
            r[i] = search(A, i);
        }
        return r;
    }

   public int search(int[] A, int i) {
       int j,k;
       j=i+1;
       k=i-1;
       int result = 0;
       if(j <= A.length-1 && (A[j]>A[i]))
               return Math.abs(j-i);
       j++;
        while(k>=0 || j < A.length){
            if(k >= 0 && A[k] > A[i]){
                return Math.abs(i-k);
            }else if(j < A.length && A[j] > A[i]){
                return Math.abs(i-j);
            }else{
                j++;
                k--;
            }
        }
        return result;
   }    
   int maxDistance(int arr[], int n)
   {
       // Used to store element to first index mapping
      // Map<int, int> mp;
	   
       int N = A.length;
       int result = 0;
       for (int i = 0; i < N; i++)
           for (int j = 0; j < N; j++)
               if (A[i] == A[j])
                   result = Math.max(result, Math.abs(i - j));
       return result;
       
       HashMap< Integer,Integer> mp = 
               new HashMap< Integer,Integer>();
       // Traverse elements and find maximum distance between
       // same occurrences with the help of map.
       int max_dist = 0;
       for (int i=0; i<n; i++)
       {
           // If this is first occurrence of element, insert its
           // index in map
           if (!mp.containsKey(arr[i]))
               mp.put(arr[i], i);
    
           // Else update max distance
           else
               max_dist = Math.max(max_dist, Math.abs(i-mp.get(arr[i])));
       }
    
       return max_dist;
   }
	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
		// System.out.println("see"+answer(6));
		System.out.println("see" + find_numbers(3, 5, 23));
		 int A[] = { 4, 3, 1, 4, -1, 2, 1, 5, 7 };
		    int R[] = ascenderArray(A);
		    System.out.println(Arrays.toString(R));
		}

}
