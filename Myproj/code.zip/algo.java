import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Spliterator;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import javafx.util.Pair;


class Person {
	 		/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Person [" + (name != null ? "name=" + name + ", " : "") + (age != null ? "age=" + age : "") + "]";
	}

			String name;
	    Integer age;   /**
		 * @return the name
		 */
		public String getName() {
			return name;
		}
		/**
		 * @param name the name to set
		 */
		public void setName(String name) {
			this.name = name;
		}
		/**
		 * @return the age
		 */
		public Integer getAge() {
			return age;
		}
		/**
		 * @param age the age to set
		 */
		public void setAge(Integer age) {
			this.age = age;
		}

		public Person(String name, Integer age) {
			super();
			this.name = name;
			this.age = age;
		}
	       
	    // standard constructors, getters and setters
	}


public class algo {
	
	
	public static double sqrt(int number) {
		double t;
	 
		double squareRoot = number / 2;
	 
		do {
			t = squareRoot;
			squareRoot = (t + (number / t)) / 2;
		} while ((t - squareRoot) != 0);
	 
		return squareRoot;
	}
	
    static int simpleArraySum(int[] ar) {
        /*
         * Write your code here.
         */
return Arrays.stream(ar).sum();
    }
    
    static int total = 0;
    private Stream<Double> sqrtStream(double x) {
//      Function<Double, Double> improve = guess -> (guess + x / guess) / 2;
      Function<Double, Double> improve = guess -> {
          total++;
          return (guess + x / guess) / 2;
      };
      
      // The atomic reference here is a way to get around the problem that we can't refer to guesses on the RHS of our assignment
      // to guesses itself - the compiler would complain that "The local variable guesses may not have been initialized."
      //
      // In Scala the `lazy val` gets around this ordering problem.
      //
      // What's important is that all references to guesses refer to the same value. So is the memoization aspect of `lazy val`
      // important in this case?
      //
      // Under the covers `lazy val` is implemented as a method call with a backing variable so it's important there that the method
      // call remembers its result in the backing variable (rather than recalculating it) - see http://stackoverflow.com/a/23856501
      //
      // We do capture guesses in the closure created for the reference.set line. So we do hang onto the value in order to use it
      // again later but I wouldn't call this memoization in the sense of "an optimization technique used primarily to speed up
      // computer programs by storing the results of expensive function calls and returning the cached result when the same inputs
      // occur again." (Wikipedia).
      //
      // In any case here it's clear that the reference to guesses in the reference.set step will not result in guesses being
      // reevaluated, i.e. a new Stream.cons(1d, ...) being created.
      //
      // So the crucial laziness is the lazy Stream.tail.
      //
      AtomicReference<Supplier<Stream<Double>>> reference = new AtomicReference<>();
      //Stream<Double> guesses = Stream.cons(1d, () -> reference.get().get());
      Stream<Double> guesses = null;
      
      reference.set(() -> guesses.map(improve));
      
      return guesses;
  }
    static int diagonalDifference(int[][] a) {
        /*
         * Write your code here.
         */
        int diagonalValue  = 0;
for(int i = 0; i < a.length ; i++){
    
  for(int j = 0; j < a[i].length ; j++) {
      if(i==j){
          
            diagonalValue+=a[i][j];  
            } 
          if(i==a[i].length-j){
          
           diagonalValue-=a[i][j];  
            }
    }
}
return (diagonalValue < 0) ? diagonalValue : -diagonalValue;
}
  
    static boolean isPrime(int n) {  for (int i = 0 ; i < n ; i++)
        for (int j = 0 ; j < n ; j++)
       if(i<j)  System.out.print("#");
        else
             System.out.print(" ");
    
       // System.out.println("Checking if " + n + " is a prime.");
        return IntStream.range(2, n).allMatch(x -> n % x != 0);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 //IntStream stream =
				// IntStream.range(1000, 1020).filter(algo::isPrime).forEach(System.out::println);
				 IntStream.range(1000, 1020).filter(n->IntStream.range(2, n).allMatch(x -> n % x != 0)).forEach(System.out::println);
		 int arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
				            11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
		 System.out.println(
				
				 Arrays.stream(arr).filter(x -> x % 2 != 0).sum() +" "+ Arrays.stream(arr).filter(x -> x % 2 != 0) 
         .count());
				 Pair<String, Integer> pair = new Pair<String, Integer>("A pair", 55);
		   ArrayList<String> names = new ArrayList<String>();
        names.add("one");
        names.add("five");
        names.add("seven");
        names.add("eight");
        names.add("ten");
		
		   IntStream.range(1, names.size())
           .mapToObj(i -> new Pair<String, String>(names.get(i-1), names.get(i)))
           .forEach(System.out::println);
		  IntStream.iterate(0, i -> i + 2).limit(3).forEach(System.out::println);
     
        System.out.println(names.stream().max(Comparator.comparingInt(String::length)));	
      
       // System.out.println(names.stream().max(null));
        Person alex = new Person("ulex", 23);
        Person paul = new Person("Paul", 23);
        Person john = new Person("John", 40);
        Person peter = new Person("Peter", 32);
        List<Person> people = Arrays.asList(alex, john, peter, paul);
     
        // then
        Person minByAge = people
          .stream()
          .min(Comparator.comparing(Person::getAge).thenComparing(Person::getName))
          .orElseThrow(NoSuchElementException::new);
        System.out.println(minByAge);
 
	}

}
