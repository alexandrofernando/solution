package str;


public class Fraction {
	 
    int numerator;
    int denominator;
 
    /**
    * Constructor
    * 
    * @param numr
    * @param denr
    */
    public Fraction(int numr, int denr) {
	numerator = numr;
	denominator = denr;
	int gcd = calculateGCD(numerator, denominator);
	numerator /= gcd;
	denominator /= gcd;
    }
 
    public static int [] simplify (int [] fraction  ) {
    	
    	int gcd = gcd(fraction[0], fraction[1]);
    	int numr = fraction[0]/= gcd,  denr = fraction[1]/= gcd ;
		return new int[] {numr, denr};
		}
		
    public static int []     add(int [] fract1, int [] fract2) {
    
   return simplify( new int[] {fract1[0] * fract2[1] +  fract1[1] * fract2[0], fract1[1] * fract2[1]});
}
    /**
    * Calculates gcd of two numbers
    * 
    * @param numerator
    * @param denominator
    * @return
    */
    public static int GCD(int numerator, int denominator) {
	if (numerator % denominator == 0) {
             return denominator;
        }
	return GCD(denominator, numerator % denominator);
	}
    
    public static int gcd(int numerator, int denominator) {
		int testNum = numerator;
		int testDen = denominator;
		
		if (testNum < 0)
			testNum = 0 - testNum;
		else if (testDen < 0)
			testDen = 0 - testDen;
		
		while (testNum != testDen){
			if (testNum > testDen)
				testNum -= testDen;
			else
				testDen -= testNum;
		}
		return testNum;
	}
    
    
    public int calculateGCD(int numerator, int denominator) {
	if (numerator % denominator == 0) {
             return denominator;
        }
	return calculateGCD(denominator, numerator % denominator);
	}
 
    /**
    * Reduce the fraction to lowest form
    */

 
    /**
    * Adds two fractions
    * 
    * @param fractionTwo
    * @return
    */
    public Fraction add(Fraction fractionTwo) {
	int numer = (numerator * fractionTwo.denominator) + 
                            (fractionTwo.numerator * denominator);
	int denr = denominator * fractionTwo.denominator;
	return new Fraction(numer, denr);
    }
 
    /**
    * Subtracts two fractions
    * 
    * @param fractionTwo
    * @return
    */
    public Fraction subtract(Fraction fractionTwo) {
        int newNumerator = (numerator * fractionTwo.denominator) - 
                                 (fractionTwo.numerator * denominator);
	int newDenominator = denominator * fractionTwo.denominator;
	Fraction result = new Fraction(newNumerator, newDenominator);
	return result;
    }
 
    /**
    * Multiples two functions
    * 
    * @param fractionTwo
    * @return
    */
    public Fraction multiply(Fraction fractionTwo) {
	int newNumerator = numerator * fractionTwo.numerator;
	int newDenominator = denominator * fractionTwo.denominator;
	Fraction result = new Fraction(newNumerator, newDenominator);
	return result;
    }
 
    /**
    * Divides two fractions
    * 
    * @param fractionTwo
    * @return
    */
    public Fraction divide(Fraction fractionTwo) {
	int newNumerator = numerator * fractionTwo.denominator;
	int newDenominator = denominator * fractionTwo.numerator;
	Fraction result = new Fraction(newNumerator, newDenominator);
	return result;
    }
 
    /**
    * Returns string representation of the fraction
    */
    @Override
    public String toString() {
	return this.numerator + "/" + this.denominator;
    }
 
    public static void main(String[] args) {
	Fraction f1 = new Fraction(25, 35);
	System.out.println(f1.toString());
	Fraction f2 = new Fraction(2, 7);
	Fraction f3 = f1.add(f2);
	int[] data = add( new int[] {25, 35},  new int[] {2, 7});
	System.out.println("Result of addition of " + f1 + " and " + f2 + " is : " + f3);
	System.out.println("Result of addition of " + f1 + " and " + f2 + " is : " + data[0] +" "+ data[1]);
	f3 = f1.subtract(f2);
	System.out.println("Result of subtraction of " + f1 + " and " + f2 + " is : " + f3);
	f3 = f1.divide(f2);
	System.out.println("Result of division of " + f1 + " and " + f2 + " is : " + f3);
	f3 = f1.multiply(f2);
	System.out.println("Result of multiplication of " + f1 + " and " + f2 + " is : " + f3);
    }
}