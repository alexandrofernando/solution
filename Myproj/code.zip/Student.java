import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Student {

    String stud_id;
    String stud_name;
    String stud_location;
    int Notes;

    public int getStud_note() {
        return Notes;
    }
    public String getStud_id() {
        return stud_id;
    }
    
    public String getStud_name() {
        return stud_name;
    }

    public String getStud_location() {
        return stud_location;
    }

    Student(int Notes,  String sname, String location) {
    	this.Notes = Notes;
     //   this.stud_id = sid;
        this.stud_name = sname;
        this.stud_location = location;
    }
    Student(int Notes, String sid, String sname, String slocation) {
    	this.Notes = Notes;
        this.stud_id = sid;
        this.stud_name = sname;
        this.stud_location = slocation;

    }
    
    
    
    
    public static void main(String args[])
    {  

    
    	
    	
    	Stream.of("a1", "a2", "a3")
        .findFirst()
        .ifPresent(System.out::println);
    	


        Stream<Student> studs =    Stream.of(new Student[] {new Student(10, "1726", "John", "New York"),
                new Student(12, "4321", "Max", "California"),
                new Student(6 ,"2234", "Max", "Los Angeles"),
                new Student(17, "7765", "Sam", "California")});
   	 
        List<Student> stud = Arrays.asList(new Student[] {new Student(10, "1726", "John", "New York"),
                new Student(12, "4321", "Max", "California"),
                new Student(6 ,"2234", "Alex", "Los Angeles"),
                new Student(17, "7765", "Sam", "N")});
        
    	stud.stream()
        .findFirst()
        .ifPresent(System.out::println);
        
        	studs.forEachOrdered((System.out::println));
        
      Map<String, Map<Object, List<Student>>> map= stud.stream().collect(Collectors.groupingBy(Student::getStud_name,Collectors.groupingBy(Student::getStud_location)));
              System.out.println(map);//print by name and then location
                Map<String, List<Student>> studlistGrouped =     stud.stream().collect(Collectors.groupingBy(w -> w.stud_location));
                System.out.println(studlistGrouped);
                
                
                Map<String, Map<String, Double>> 
                averageAgeByCountryAndCity = stud.
                     stream().
                       collect(
                         Collectors.
                             groupingBy(
                            		 Student::getStud_name,
                                 Collectors.
                                     groupingBy(
                                    		 Student::getStud_location,
                                         Collectors.averagingDouble(Student::getStud_note)
                                               )
                                        )
                          );
                
                System.out.println(averageAgeByCountryAndCity);
    }
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Student [" + (stud_id != null ? "stud_id=" + stud_id + ", " : "")
				+ (stud_name != null ? "stud_name=" + stud_name + ", " : "")
				+ (stud_location != null ? "stud_location=" + stud_location + ", " : "") + "Notes=" + Notes
		 + "]";
	}

}

class Temp
{
    static void miniMaxSum(int[] arr) {
        /*
         * Write your code here.
         */
        int min = 0,  max = 0,   sum = 0;
   
for (int i = 0; i < arr.length; i ++){
   max = max < max ? sum:max;
   min = min > max ? sum:min;
    for (int j = 0; j < arr.length; j ++)
     if (i!=j)   sum++; }
        
        System.out.println(min+" "+max);
    }
}