import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class PairsEqualToDiff {

public static void main(String[] args) {
    int a[] = {1,10,5,8,2,12,6,4};
   int x = 3;
    
    System.out.println(  "Here are all pairs in the array which have difference equal to: "+x );
    findPairsDifference(a,x);

}


  // O(N) use a Map to insert values as keys 
    static void findPairsDifference(int[]a, int diff){
        Map<Integer, Integer> pairs1 = new HashMap<Integer, Integer>();
        Map<Integer, Integer> pairs2 = new HashMap<Integer, Integer>();
        for(int i=0; i<a.length; i++){
            if(pairs1.containsKey(diff+a[i]))
                System.out.println("("+a[i]+","+(diff+a[i])+")");
            else
               pairs1.put(a[i], 0);
        }
       
        for(int i=a.length-1; i>0; i--){
            if(pairs2.containsKey(a[i]))
                System.out.println("("+(a[i]+diff)+","+(a[i])+")");
            else
               pairs2.put(a[i]-diff, 0);
        }
    }

   
}

 